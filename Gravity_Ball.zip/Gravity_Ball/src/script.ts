interface Circle {
    x: number;
    y: number;
    radius: number;
    color: string;
    velocityY: number;
    gravity: number;
  }

const canvas: HTMLCanvasElement = document.querySelector('canvas')!;
const ctx = canvas.getContext('2d') as  CanvasRenderingContext2D | null


let circles: any[] = [];

function drawCircle(circle: Circle) {
  ctx?.beginPath();
  ctx?.arc(circle.x, circle.y, circle.radius, 0, 2 * Math.PI);
  if(ctx){
     ctx.fillStyle = circle.color
  }

  ctx?.fill();
  ctx?.closePath();
}

function update(circle: Circle) {
  circle.y += circle.velocityY;
  circle.velocityY += circle.gravity;
 
 
  if (circle.y + circle.radius > canvas.height) {
    circle.velocityY *= -0.5;
    circle.y = canvas.height - circle.radius;
  }

  if (Math.abs(circle.velocityY) < 0.1) {
    // circle.velocityY = 0;
    circle.gravity = 0.1
    
  }

  drawCircle(circle);
}

function onClick(event: any) {
  const newCircle = {
    x: event.clientX ,
    y: event.clientY ,
    radius: 20,
    color: '#3498db',
    velocityY: 0,
    gravity: 0.5
  };

  circles.push(newCircle);
}

function gameLoop() {
  ctx?.clearRect(0, 0, canvas.width, canvas.height);

  circles.forEach(circle => {
    update(circle);
  });


  requestAnimationFrame(gameLoop);
}

canvas.addEventListener('click', onClick);

gameLoop();