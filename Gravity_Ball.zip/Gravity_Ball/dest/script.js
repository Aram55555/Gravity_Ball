"use strict";
const canvas = document.querySelector('canvas');
const ctx = canvas.getContext('2d');
let circles = [];
function drawCircle(circle) {
    ctx === null || ctx === void 0 ? void 0 : ctx.beginPath();
    ctx === null || ctx === void 0 ? void 0 : ctx.arc(circle.x, circle.y, circle.radius, 0, 2 * Math.PI);
    if (ctx) {
        ctx.fillStyle = circle.color;
    }
    ctx === null || ctx === void 0 ? void 0 : ctx.fill();
    ctx === null || ctx === void 0 ? void 0 : ctx.closePath();
}
function update(circle) {
    circle.y += circle.velocityY;
    circle.velocityY += circle.gravity;
    if (circle.y + circle.radius > canvas.height) {
        circle.velocityY *= -0.5;
        circle.y = canvas.height - circle.radius;
    }
    if (Math.abs(circle.velocityY) < 0.1) {
        // circle.velocityY = 0;
        circle.gravity = 0.1;
    }
    drawCircle(circle);
}
function onClick(event) {
    const newCircle = {
        x: event.clientX,
        y: event.clientY,
        radius: 20,
        color: '#3498db',
        velocityY: 0,
        gravity: 0.5
    };
    circles.push(newCircle);
}
function gameLoop() {
    ctx === null || ctx === void 0 ? void 0 : ctx.clearRect(0, 0, canvas.width, canvas.height);
    circles.forEach(circle => {
        update(circle);
    });
    requestAnimationFrame(gameLoop);
}
canvas.addEventListener('click', onClick);
gameLoop();
